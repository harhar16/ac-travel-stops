# ☕ Sip Happens

Find coffee shops with Wi-Fi, workspace vibes, and strong espresso energy—based on your ZIP code. Think of it as Yelp, but without the ads, emotional trauma, or "sponsored gas stations."

## 🚀 Features

- Enter a ZIP code and find nearby coffee shops using Google Places API
- View ratings, addresses, and workspace-relevant vibes
- Mark places as **Favorites** or **Recommended**
- Backend stores your picks in a lightweight SQLite database
- Minimalist modern UI using Tailwind CSS (no DMV styling here)

---

## 🧠 Tech Stack

- HTML + Tailwind CSS + Vanilla JavaScript
- Node.js + Express
- SQLite for local database
- Google Places API for live coffee data

---

## 🔧 Setup Instructions

1. **Clone the repo**
   ```bash
   git clone https://github.com/YOUR_USERNAME/sip-happens.git
   cd sip-happens

Install dependencies

bash
Copy
Edit
npm install
Create your .env file

bash
Copy
Edit
touch .env
Then paste this inside:

ini
Copy
Edit
GOOGLE_API_KEY=your_google_places_api_key_here
Start the server

bash
Copy
Edit
node server.js
Open the app Visit http://localhost:3000 in your browser and sip like a champ.

